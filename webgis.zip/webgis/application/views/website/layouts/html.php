<!DOCTYPE html>
<html lang="en">
<?php include 'head.php';?>
<body class="bg-shape">

  <!--================ Header Menu Area start =================-->
  <?php include 'header.php';?>
  <!--================Header Menu Area =================-->
  <?=$content?>
  <!--================Blog section End =================-->
  <?php include 'footer.php';?>
  <!-- ================ End footer Area ================= -->
  <?php include 'javascript.php';?>


</body>
</html>