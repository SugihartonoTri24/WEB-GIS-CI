  <script src="<?=templates('vendors/jquery/jquery-3.2.1.min.js','website')?>"></script>
  <script src="<?=templates('vendors/bootstrap/bootstrap.bundle.min.js','website')?>"></script>
  <script src="<?=templates('vendors/owl-carousel/owl.carousel.min.js','website')?>"></script>
  <script src="<?=templates('vendors/nice-select/jquery.nice-select.min.js','website')?>"></script>
  <script src="<?=templates('js/jquery.ajaxchimp.min.js','website')?>"></script>
  <script src="<?=templates('js/mail-script.js','website')?>"></script>
  <script src="<?=templates('js/skrollr.min.js','website')?>"></script>
  <script src="<?=templates('js/main.js','website')?>"></script>