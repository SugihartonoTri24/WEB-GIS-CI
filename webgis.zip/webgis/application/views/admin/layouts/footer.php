 <footer>
  <div class="pull-right">
    
    <strong>Copyright &copy; 2020 | Nasrullah Siddik <a href="https://gitlab.com/as-shiddiq" target="_BLANK">Gitlab</a> | <a href="bit.ly/YTNSiddik" target="_BLANK">YTChannel</a>.</strong> | Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
  </div>
  <div class="clearfix"></div>
</footer>