<?=content_open('Halaman Beranda')?>
     <?=$this->session->flashdata('info')?>
<?=content_close()?>