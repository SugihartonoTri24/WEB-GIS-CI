<?=content_open($title)?>
 	<div id="map"></div>
<?=content_close()?>
